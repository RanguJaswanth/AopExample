
package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class AopBankDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AopBankDemoApplication.class, args);
    }

    @Bean
    CommandLineRunner demo(BankService bank) {
        return args -> {
            System.out.println("=== Simple Bank Demo (AOP + DI + Lifecycle) ===");

            bank.depositToSavings(500);
            bank.depositToCurrent(1000);

            try {
                bank.withdrawFromSavings(300);     // valid
                bank.withdrawFromCurrent(7000);    // might be valid (overdraft allowed)
                bank.withdrawFromSavings(10000);   // will fail -> triggers @AfterThrowing
            } catch (Exception e) {
                System.out.println("Caught in main: " + e.getMessage());
            }

            System.out.println("Savings balance: " + bank.savingsBalance());
            System.out.println("Current balance: " + bank.currentBalance());
        };
    }
}
