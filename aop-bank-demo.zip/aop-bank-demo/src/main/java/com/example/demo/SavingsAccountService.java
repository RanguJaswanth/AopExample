package com.example.demo;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

@Service("savingsAccount")
public class SavingsAccountService implements AccountService {

    private double balance = 1000;

    @PostConstruct
    public void init() {
        System.out.println("[SavingsAccountService] @PostConstruct: initialized with balance = " + balance);
    }

    @PreDestroy
    public void cleanup() {
        System.out.println("[SavingsAccountService] @PreDestroy: cleanup before shutdown.");
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Savings: Deposited " + amount);
    }

    @Override
    public void withdraw(double amount) {
        if (balance - amount < 100) {
            throw new RuntimeException("Savings: minimum balance (₹100) must be maintained!");
        }
        balance -= amount;
        System.out.println("Savings: Withdrawn " + amount);
    }

    @Override
    public double balance() {
        return balance;
    }

    @Override
    public String type() {
        return "SAVINGS";
    }
}
