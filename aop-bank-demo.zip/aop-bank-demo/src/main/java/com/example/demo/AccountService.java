package com.example.demo;

public interface AccountService {

    void deposit(double amount);
    void withdraw(double amount);
    double balance();
    String type(); // "SAVINGS" or "CURRENT"


}
