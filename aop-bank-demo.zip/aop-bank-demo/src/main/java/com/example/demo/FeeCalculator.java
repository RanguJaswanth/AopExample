package com.example.demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Component;

@Component
public class FeeCalculator {

    @PostConstruct
    public void init() {
        System.out.println("[FeeCalculator] @PostConstruct: ready.");
    }

    @PreDestroy
    public void cleanup() {
        System.out.println("[FeeCalculator] @PreDestroy: releasing resources.");
    }

    public double fee(String accountType, double amount) {
        // Very simple fee rule: Savings 1%, Current 0.5%
        double rate = "SAVINGS".equals(accountType) ? 0.01 : 0.005;
        return amount * rate;
    }
}
