package com.example.demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("currentAccount")
@Primary  // <- default when no @Qualifier is specified
public class CurrentAccountService implements AccountService {

    private double balance = 5000;

    @PostConstruct
    public void init() {
        System.out.println("[CurrentAccountService] @PostConstruct: initialized with balance = " + balance);
    }

    @PreDestroy
    public void cleanup() {
        System.out.println("[CurrentAccountService] @PreDestroy: cleanup before shutdown.");
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Current: Deposited " + amount);
    }

    @Override
    public void withdraw(double amount) {
        // Current account allows up to -1000 overdraft
        if (balance - amount < -1000) {
            throw new RuntimeException("Current: overdraft limit exceeded!");
        }
        balance -= amount;
        System.out.println("Current: Withdrawn " + amount);
    }

    @Override
    public double balance() {
        return balance;
    }

    @Override
    public String type() {
        return "CURRENT";
    }
}