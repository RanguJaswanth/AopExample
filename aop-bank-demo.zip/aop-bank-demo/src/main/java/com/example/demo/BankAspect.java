package com.example.demo;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class BankAspect {

    // Pointcut: any public method in our package
    @Pointcut("execution(public * com.example.demo..*(..))")
    public void bankOps() {}

    @Before("bankOps()")
    public void before(JoinPoint jp) {
        System.out.println("[AOP @Before] " + jp.getSignature().toShortString()
                + " args=" + java.util.Arrays.toString(jp.getArgs()));
    }

    @After("bankOps()")
    public void after(JoinPoint jp) {
        System.out.println("[AOP @After] " + jp.getSignature().toShortString());
    }

    @AfterReturning(pointcut = "bankOps()", returning = "ret")
    public void afterReturning(JoinPoint jp, Object ret) {
        System.out.println("[AOP @AfterReturning] " + jp.getSignature().toShortString()
                + " returned=" + ret);
    }

    @AfterThrowing(pointcut = "bankOps()", throwing = "ex")
    public void afterThrowing(JoinPoint jp, Throwable ex) {
        System.out.println("[AOP @AfterThrowing] " + jp.getSignature().toShortString()
                + " threw=" + ex.getMessage());
    }
}