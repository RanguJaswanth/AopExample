package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class BankService {

    private final AccountService savings;     // injected by qualifier
    private final AccountService current;     // injected by type (uses @Primary)
    private final FeeCalculator feeCalculator;

    @Autowired
    public BankService(@Qualifier("savingsAccount") AccountService savings,
                       AccountService current,  // resolves to @Primary bean (CurrentAccountService)
                       FeeCalculator feeCalculator) {
        this.savings = savings;
        this.current = current;
        this.feeCalculator = feeCalculator;
    }

    public void depositToSavings(double amount) {
        savings.deposit(amount);
    }

    public void depositToCurrent(double amount) {
        current.deposit(amount);
    }

    public void withdrawFromSavings(double amount) {
        double fee = feeCalculator.fee(savings.type(), amount);
        savings.withdraw(amount + fee);
        System.out.println("[BankService] Savings fee applied: " + fee);
    }

    public void withdrawFromCurrent(double amount) {
        double fee = feeCalculator.fee(current.type(), amount);
        current.withdraw(amount + fee);
        System.out.println("[BankService] Current fee applied: " + fee);
    }

    public double savingsBalance() { return savings.balance(); }
    public double currentBalance() { return current.balance(); }
}
