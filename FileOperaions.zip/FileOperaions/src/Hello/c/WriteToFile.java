package Hello.c;
import java.io.*;
public class WriteToFile {
    public static void main(String[] args) {
        try {
            FileWriter fw = new FileWriter("C:\\Users\\2699026\\Desktop\\New folder (2)\\FileOperaions\\Demo.txt"); // creates file if not exists
            fw.write("Hello, this is a sample text written using File IO.\n");
            fw.write("Java FileWriter makes writing to files easy.");
            fw.close(); // close the stream
            System.out.println("Data written to file successfully!");
        } 
        catch (IOException e) {
            System.out.println("Error occurred: " + e.getMessage());
        }
    }
}

