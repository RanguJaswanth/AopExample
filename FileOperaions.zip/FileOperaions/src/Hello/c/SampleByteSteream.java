package Hello.c;
import java.io.*;
public class SampleByteSteream {
    public static void main(String[] args) {
    	String data = "This is some text to write to the file.";
        try (FileOutputStream fos = new FileOutputStream("Demo1.txt")) {
            fos.write(data.getBytes()); // Convert String to bytes and write
        } 
        catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }

}
}
