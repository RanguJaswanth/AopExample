package Hello.c;
import java.io.*;
import java.util.*;
public class ScannerDemoReader {
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("C:\\Users\\2699026\\Desktop\\New folder (2)\\FileOperaions\\Demo.txt");
		Scanner sc = new Scanner(file);
		while(sc.hasNextLine()) {
			System.out.println(sc.nextLine());
		}
		sc.close();
	}

}
