package Hello.c;

import java.io.*;
import java.io.IOException;

public class ReadFromFile1 {
	public static void main(String[] args) {
        String filePath = "C:\\Users\\2699026\\Desktop\\New folder (2)\\FileOperaions\\Demo.txt"; // Replace with the actual path to your file

        try (FileReader reader = new FileReader(filePath)) {
        	BufferedReader br = new BufferedReader(reader);
            String line;
            while ((line = br.readLine())!= null) {
                System.out.println(line); // Process each line as needed
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
